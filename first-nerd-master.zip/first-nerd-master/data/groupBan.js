
const banned = {
  "318625403" : true,






}
